<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Aureals Black
 */
?>



			</div><!-- #content -->
		</div><!-- .main-page -->
	</div><!-- .main-content-area -->

</body>
</html>
